CREATE VIEW [dbo].[view_test_form] AS
  SELECT
    '001'              AS id,
    'ghl'              AS loginName,
    'GONGHL'           AS displayName,
    '835376597@qq.com' AS email